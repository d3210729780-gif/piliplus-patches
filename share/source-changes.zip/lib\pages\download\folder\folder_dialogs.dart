import 'package:PiliPlus/common/widgets/dialog/dialog.dart';
import 'package:PiliPlus/common/widgets/dialog/simple_dialog_option.dart';
import 'package:PiliPlus/services/download/download_folder_store.dart';
import 'package:PiliPlus/services/download/download_service.dart';
import 'package:get/get.dart';
import 'package:material_ui/material_ui.dart';

/// 文件夹改动后让离线缓存列表重新分组
void _refreshDownloadList() {
  if (Get.isRegistered<DownloadService>()) {
    Get.find<DownloadService>().flagNotifier.refresh();
  }
}

/// 新建文件夹，返回新文件夹 id（取消返回 null）
Future<int?> showCreateFolderDialog(BuildContext context) async {
  final textController = TextEditingController();
  final name = await showDialog<String>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('新建文件夹'),
      content: TextField(
        controller: textController,
        autofocus: true,
        maxLength: 30,
        decoration: const InputDecoration(
          hintText: '文件夹名称',
          counterText: '',
        ),
        onSubmitted: (value) => Navigator.of(context).pop(value),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('取消'),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(textController.text),
          child: const Text('确定'),
        ),
      ],
    ),
  );
  final trimmed = name?.trim() ?? '';
  if (trimmed.isEmpty) return null;
  final id = await DownloadFolderStore.create(trimmed);
  _refreshDownloadList();
  return id;
}

/// 把条目移动到文件夹 / 移出文件夹
Future<void> showMoveToFolderDialog(
  BuildContext context,
  List<int> cids,
) async {
  if (cids.isEmpty) return;
  final folders = DownloadFolderStore.folders;
  final current = DownloadFolderStore.folderOf(cids.first);
  final hasFolder = cids.any((cid) => DownloadFolderStore.folderOf(cid) != null);

  await showDialog<void>(
    context: context,
    builder: (context) => SimpleDialog(
      clipBehavior: Clip.hardEdge,
      contentPadding: const EdgeInsets.symmetric(vertical: 12),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: Text(
            '移动到文件夹 (${cids.length})',
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
          ),
        ),
        for (final folder in folders)
          DialogOption(
            onPressed: () async {
              Navigator.of(context).pop();
              await DownloadFolderStore.moveTo(cids, folder.id);
              _refreshDownloadList();
            },
            child: Row(
              children: [
                Icon(
                  folder.id == current
                      ? Icons.folder
                      : Icons.folder_outlined,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    folder.name,
                    style: const TextStyle(fontSize: 14),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (folder.id == current)
                  const Icon(Icons.check, size: 18),
              ],
            ),
          ),
        DialogOption(
          onPressed: () async {
            Navigator.of(context).pop();
            final folderId = await showCreateFolderDialog(context);
            if (folderId != null) {
              await DownloadFolderStore.moveTo(cids, folderId);
              _refreshDownloadList();
            }
          },
          child: const Row(
            children: [
              Icon(Icons.create_new_folder_outlined, size: 20),
              SizedBox(width: 10),
              Text('新建文件夹…', style: TextStyle(fontSize: 14)),
            ],
          ),
        ),
        if (hasFolder)
          DialogOption(
            onPressed: () async {
              Navigator.of(context).pop();
              await DownloadFolderStore.moveTo(cids, null);
              _refreshDownloadList();
            },
            child: const Row(
              children: [
                Icon(Icons.folder_off_outlined, size: 20),
                SizedBox(width: 10),
                Text('移出文件夹', style: TextStyle(fontSize: 14)),
              ],
            ),
          ),
      ],
    ),
  );
}

/// 管理已建的文件夹：重命名 / 删除
Future<void> showFolderManagerDialog(BuildContext context) async {
  final folders = DownloadFolderStore.folders;
  await showDialog<void>(
    context: context,
    builder: (context) => SimpleDialog(
      clipBehavior: Clip.hardEdge,
      contentPadding: const EdgeInsets.symmetric(vertical: 12),
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: Text(
            '管理文件夹',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
          ),
        ),
        if (folders.isEmpty)
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: Text(
              '还没有文件夹，先新建一个',
              style: TextStyle(fontSize: 13),
            ),
          ),
        for (final folder in folders)
          DialogOption(
            child: Row(
              children: [
                const Icon(Icons.folder_outlined, size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '${folder.name}'
                    '（${DownloadFolderStore.cidsOf(folder.id).length}）',
                    style: const TextStyle(fontSize: 14),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  tooltip: '重命名',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.edit_outlined, size: 18),
                  onPressed: () async {
                    Navigator.of(context).pop();
                    await _renameFolder(context, folder.id, folder.name);
                  },
                ),
                IconButton(
                  tooltip: '删除文件夹',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.delete_outline, size: 18),
                  onPressed: () async {
                    Navigator.of(context).pop();
                    await _deleteFolder(context, folder.id, folder.name);
                  },
                ),
              ],
            ),
          ),
      ],
    ),
  );
}

Future<void> _renameFolder(
  BuildContext context,
  int id,
  String oldName,
) async {
  final textController = TextEditingController(text: oldName);
  final name = await showDialog<String>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('重命名文件夹'),
      content: TextField(
        controller: textController,
        autofocus: true,
        maxLength: 30,
        decoration: const InputDecoration(counterText: ''),
        onSubmitted: (value) => Navigator.of(context).pop(value),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('取消'),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(textController.text),
          child: const Text('确定'),
        ),
      ],
    ),
  );
  final trimmed = name?.trim() ?? '';
  if (trimmed.isEmpty) return;
  await DownloadFolderStore.rename(id, trimmed);
  _refreshDownloadList();
}

Future<void> _deleteFolder(
  BuildContext context,
  int id,
  String name,
) async {
  await showConfirmDialog(
    context: context,
    title: Text('删除文件夹「$name」？视频不会被删除'),
    onConfirm: () async {
      await DownloadFolderStore.remove(id);
      _refreshDownloadList();
    },
  );
}
