import 'package:PiliPlus/grpc/bilibili/app/listener/v1.pb.dart'
    show Author, BKArcPart, BKArchive, DetailItem, PlayItem;
import 'package:PiliPlus/models_new/download/bili_download_entry_info.dart';
import 'package:PiliPlus/plugin/pl_player/models/data_source.dart';
import 'package:PiliPlus/services/download/download_folder_store.dart';
import 'package:PiliPlus/services/download/download_service.dart';
import 'package:fixnum/fixnum.dart' show Int64;
import 'package:get/get.dart';

/// 「听视频」的本地(离线)播放源。
///
/// 由下载缓存里的 [BiliDownloadEntryInfo] 转换而来：优先播分离出来的音频轨
/// (m4s)，没有音轨时直接播视频文件(mp4)，两种 media_kit 都能读。
///
/// 之所以要单独搞一层，是因为 [AudioPage] 原本完全依赖
/// `bilibili.app.listener.v1` 的 gRPC 接口拿播放列表和播放地址，
/// 离线时这两样都没有。
class LocalAudioItem {
  /// 实际交给播放器的本地文件路径
  final String path;

  final String title;
  final String cover;
  final String upName;
  final String upAvatar;
  final int upMid;
  final int avid;
  final int cid;
  final String bvid;

  /// 毫秒
  final int durationMs;

  /// 秒，0 表示未知
  final int publishTime;

  /// 下载时间戳，用于「无序」排序
  final int downloadTime;

  const LocalAudioItem({
    required this.path,
    required this.title,
    required this.cover,
    required this.avid,
    required this.cid,
    required this.durationMs,
    this.bvid = '',
    this.upName = '',
    this.upAvatar = '',
    this.upMid = 0,
    this.publishTime = 0,
    this.downloadTime = 0,
  });

  int get durationSeconds => durationMs <= 0 ? 0 : (durationMs / 1000).round();

  factory LocalAudioItem.fromEntry(BiliDownloadEntryInfo entry) {
    final source = FileSource(
      dir: entry.entryDirPath,
      typeTag: entry.typeTag ?? '',
      isMp4: entry.mediaType == 1,
      hasDashAudio: entry.hasDashAudio,
    );
    return LocalAudioItem(
      path: source.audioSource ?? source.videoSource,
      title: entry.showTitle,
      cover: entry.cover,
      avid: entry.avid,
      cid: entry.cid,
      bvid: entry.bvid,
      upName: entry.ownerName ?? '',
      upMid: entry.ownerId ?? 0,
      durationMs: entry.totalTimeMilli,
      publishTime: entry.timeCreateStamp,
      downloadTime: entry.timeCreateStamp,
    );
  }

  /// 造一个最小可用的 [DetailItem]，让复用的界面(封面/标题/UP/播放列表)不用改。
  ///
  /// 离线模式下点赞/投币/收藏/评论这些联网操作是隐藏的，所以 stat 可以不填。
  DetailItem toDetailItem() => DetailItem(
    item: PlayItem(
      itemType: 1,
      oid: Int64(avid),
      subId: [Int64(cid)],
    ),
    arc: BKArchive(
      oid: Int64(avid),
      title: title,
      cover: cover,
      duration: Int64(durationSeconds),
      publish: Int64(publishTime),
      displayedOid: bvid,
    ),
    owner: Author(
      mid: Int64(upMid),
      name: upName,
      avatar: upAvatar,
    ),
    parts: [
      BKArcPart(
        oid: Int64(avid),
        subId: Int64(cid),
        title: title,
        duration: Int64(durationSeconds),
        page: 1,
      ),
    ],
    playable: 1,
  );

  /// 取 [entry] 所属的「合集 / 分P」里所有下载完成的条目，按集数顺序组成离线
  /// 播放列表。
  ///
  /// 分组规则必须和离线缓存列表一致，否则会出现「只播一首」：
  /// - 被归入自建文件夹 → 整个文件夹（文件夹等价于「合集」）
  /// - 同一合集（下载时带了 [BiliDownloadEntryInfo.seasonInfo]）→ 整个合集
  /// - 普通多P视频（同一 avid）→ 该视频的所有分P
  static List<LocalAudioItem> playlistOf(BiliDownloadEntryInfo entry) {
    final entries = <BiliDownloadEntryInfo>[];
    if (Get.isRegistered<DownloadService>()) {
      final downloadList = Get.find<DownloadService>().downloadList;
      final season = entry.seasonInfo;
      final folderId = DownloadFolderStore.folderOf(entry.cid);
      entries.addAll(
        downloadList.where((e) {
          if (!e.isCompleted) return false;
          if (folderId != null) {
            return DownloadFolderStore.folderOf(e.cid) == folderId;
          }
          if (season != null) return e.seasonInfo == season;
          return e.pageId == entry.pageId;
        }),
      );
    }
    if (!entries.any((e) => e.cid == entry.cid)) {
      entries.add(entry);
    }
    entries.sort(sortByEpisode);
    return entries.map(LocalAudioItem.fromEntry).toList();
  }

  /// 集数/分P 升序；同序号时按下载时间兜底，保证顺序稳定
  static int sortByEpisode(BiliDownloadEntryInfo a, BiliDownloadEntryInfo b) {
    final ai = a.seasonInfo?.index ?? a.sortKey;
    final bi = b.seasonInfo?.index ?? b.sortKey;
    final cmp = ai.compareTo(bi);
    return cmp != 0 ? cmp : a.timeCreateStamp.compareTo(b.timeCreateStamp);
  }

  /// 当前条目在 [playlistOf] 结果里的下标
  static int indexOfEntry(
    List<LocalAudioItem> items,
    BiliDownloadEntryInfo entry,
  ) {
    final index = items.indexWhere((e) => e.cid == entry.cid);
    return index == -1 ? 0 : index;
  }
}
