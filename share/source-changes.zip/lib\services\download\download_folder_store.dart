import 'package:PiliPlus/utils/storage.dart';
import 'package:flutter/foundation.dart';
import 'package:hive_ce/hive.dart';

/// 离线缓存里的「自建文件夹」。
///
/// 只做逻辑分组，不动磁盘上的缓存目录（挪文件会让下载记录失效）。
/// 数据放在 localCache 这个 box 里，用最普通的 Map/List 存，避免加 Hive adapter。
class DownloadFolder {
  final int id;
  final String name;

  const DownloadFolder({required this.id, required this.name});

  Map<String, dynamic> toJson() => {'id': id, 'name': name};

  factory DownloadFolder.fromJson(Map<dynamic, dynamic> json) => DownloadFolder(
    id: json['id'] as int,
    name: json['name'] as String? ?? '未命名文件夹',
  );
}

abstract final class DownloadFolderStore {
  /// 文件夹列表：`[{id, name}]`
  static const String _kFolders = 'downloadFolders';

  /// 条目归属：`{cid: folderId}`
  static const String _kItems = 'downloadFolderItems';

  static Box get _box => GStorage.localCache;

  /// 文件夹列表（按创建顺序）
  static List<DownloadFolder> get folders {
    final raw = _box.get(_kFolders);
    if (raw is! List) return const [];
    final list = <DownloadFolder>[];
    for (final item in raw) {
      if (item is Map) {
        try {
          list.add(DownloadFolder.fromJson(item));
        } catch (_) {}
      }
    }
    return list;
  }

  static DownloadFolder? folderById(int id) {
    for (final folder in folders) {
      if (folder.id == id) return folder;
    }
    return null;
  }

  /// cid -> folderId
  static Map<int, int> get assignments {
    final raw = _box.get(_kItems);
    final map = <int, int>{};
    if (raw is! Map) return map;
    raw.forEach((key, value) {
      final cid = switch (key) {
        int() => key,
        String() => int.tryParse(key),
        _ => null,
      };
      if (cid != null && value is int) map[cid] = value;
    });
    return map;
  }

  static int? folderOf(int cid) => assignments[cid];

  /// 某个文件夹里的 cid 集合
  static Set<int> cidsOf(int folderId) => assignments.entries
      .where((e) => e.value == folderId)
      .map((e) => e.key)
      .toSet();

  static Future<int> create(String name) async {
    final id = DateTime.now().millisecondsSinceEpoch;
    final list = folders.toList()
      ..add(DownloadFolder(id: id, name: name.trim()));
    await _box.put(_kFolders, list.map((e) => e.toJson()).toList());
    return id;
  }

  static Future<void> rename(int id, String name) async {
    final list = folders
        .map(
          (e) => e.id == id
              ? DownloadFolder(id: id, name: name.trim())
              : e,
        )
        .toList();
    await _box.put(_kFolders, list.map((e) => e.toJson()).toList());
  }

  /// 删文件夹不删视频，里面的条目会回到原来的分组
  static Future<void> remove(int id) async {
    final list = folders.where((e) => e.id != id).toList();
    await _box.put(_kFolders, list.map((e) => e.toJson()).toList());
    final map = assignments..removeWhere((_, value) => value == id);
    await _box.put(_kItems, map);
  }

  /// [folderId] 为 null 表示移出文件夹
  static Future<void> moveTo(Iterable<int> cids, int? folderId) async {
    final map = assignments;
    for (final cid in cids) {
      if (folderId == null) {
        map.remove(cid);
      } else {
        map[cid] = folderId;
      }
    }
    await _box.put(_kItems, map);
  }

  @visibleForTesting
  static Future<void> clearAll() async {
    await _box.delete(_kFolders);
    await _box.delete(_kItems);
  }
}
