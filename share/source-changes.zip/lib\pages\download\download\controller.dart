import 'dart:async';

import 'package:PiliPlus/common/widgets/dialog/dialog.dart';
import 'package:PiliPlus/models_new/download/bili_download_entry_info.dart';
import 'package:PiliPlus/models_new/download/download_info.dart';
import 'package:PiliPlus/pages/common/multi_select/base.dart'
    show BaseMultiSelectMixin;
import 'package:PiliPlus/services/download/download_folder_store.dart';
import 'package:PiliPlus/services/download/download_service.dart';
import 'package:PiliPlus/utils/storage.dart';
import 'package:collection/collection.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:get/get.dart';
import 'package:material_ui/material_ui.dart' show Text;

class DownloadController extends GetxController
    with BaseMultiSelectMixin<DownloadSeasonInfo> {
  final _downloadService = Get.find<DownloadService>();
  final seasons = RxList<DownloadSeasonInfo>();
  final flag = RxInt(0);

  @override
  List<DownloadSeasonInfo> get list => seasons;
  @override
  RxList<DownloadSeasonInfo> get state => seasons;

  @override
  void onInit() {
    super.onInit();
    _loadList();
    _downloadService.flagNotifier.add(_loadList);
  }

  @override
  void onClose() {
    _downloadService.flagNotifier.remove(_loadList);
    super.onClose();
  }

  Future<void> _loadList() async {
    await _downloadService.waitForInitialization;
    if (isClosed) return;
    if (_downloadService.downloadList.isEmpty) {
      seasons.clear();
      flag.value++;
      return;
    }
    final list = <DownloadSeasonInfo>[];
    for (final entry in _downloadService.downloadList) {
      final pageId = entry.pageId;
      final seasonInfo = entry.seasonInfo;
      final season = seasonInfo != null
          ? list.firstWhereOrNull((e) => e.seasonInfo == seasonInfo)
          : list.firstWhereOrNull((e) => e.pageId == pageId);
      if (season != null) {
        final page = season.pages.firstWhereOrNull((e) => e.pageId == pageId);
        if (page != null) {
          final aSortKey = entry.sortKey;
          final bSortKey = page.sortKey;
          if (aSortKey < bSortKey) {
            page
              ..cover = entry.cover
              ..sortKey = aSortKey;
          }
          page.entries.add(entry);
        } else {
          season.pages.add(
            entry.toDownloadPageInfo(pageId, sortKey: seasonInfo!.index),
          );
        }
      } else {
        list.add(
          DownloadSeasonInfo(
            pageId: pageId,
            seasonInfo: seasonInfo,
            pages: [
              entry.toDownloadPageInfo(pageId, sortKey: seasonInfo?.index),
            ],
          ),
        );
      }
    }
    _applyFolders(list);
    seasons.value = list;
    flag.value++;
  }

  /// 把自建文件夹里的条目从原分组摘出来，作为一个「文件夹」分组插到最前面
  void _applyFolders(List<DownloadSeasonInfo> list) {
    final folders = DownloadFolderStore.folders;
    if (folders.isEmpty) return;
    final folderIds = {for (final folder in folders) folder.id};
    final buckets = <int, List<BiliDownloadEntryInfo>>{};

    for (final season in list) {
      for (final page in season.pages) {
        page.entries.removeWhere((entry) {
          final folderId = DownloadFolderStore.folderOf(entry.cid);
          if (folderId == null || !folderIds.contains(folderId)) return false;
          buckets
              .putIfAbsent(folderId, () => <BiliDownloadEntryInfo>[])
              .add(entry);
          return true;
        });
      }
      season.pages.removeWhere((page) => page.entries.isEmpty);
    }
    list.removeWhere((season) => season.pages.isEmpty);

    final folderSeasons = <DownloadSeasonInfo>[];
    for (final folder in folders) {
      final entries = buckets[folder.id];
      if (entries == null || entries.isEmpty) continue;
      entries.sort((a, b) => a.sortKey.compareTo(b.sortKey));
      folderSeasons.add(
        DownloadSeasonInfo(
          seasonInfo: SeasonInfo(
            index: 0,
            id: folder.id,
            title: folder.name,
            cover: entries.first.cover,
            mid: 0,
            uname: '本地文件夹',
          ),
          pageId: 'folder-${folder.id}',
          isFolder: true,
          pages: entries.map((e) => e.toDownloadPageInfo(e.pageId)).toList(),
        ),
      );
    }
    if (folderSeasons.isNotEmpty) {
      list.insertAll(0, folderSeasons);
    }
  }

  @override
  void onRemove() {
    showConfirmDialog(
      context: Get.context!,
      title: const Text('确定删除选中视频？'),
      onConfirm: () async {
        SmartDialog.showLoading();
        final watchProgress = GStorage.watchProgress;
        for (final season in allChecked) {
          for (final page in season.pages) {
            await watchProgress.deleteAll(
              page.entries.map((e) => e.cid.toString()),
            );
            await _downloadService.deletePage(
              pageDirPath: page.dirPath,
              refresh: false,
            );
          }
        }
        _downloadService.flagNotifier.refresh();
        if (enableMultiSelect.value) {
          rxCount.value = 0;
          enableMultiSelect.value = false;
        }
        SmartDialog.dismiss();
      },
    );
  }
}
