import 'dart:io' show HttpClient;
import 'dart:math';
import 'dart:typed_data' show BytesBuilder;
import 'dart:ui' as ui;

import 'package:canvas_danmaku/models/danmaku_content_item.dart';
import 'package:material_ui/material_ui.dart';

abstract final class DmUtils {
  static const maxRasterizeSize = 8192.0;

  /// 表情图片缓存上限（直播弹幕的表情种类有限，够用）
  static const int maxEmoteCacheSize = 240;
  static final Map<String, ui.Image> _emoteCache = {};

  static double devicePixelRatio = 1;
  static final Paint _selfSendPaint = Paint()
    ..style = PaintingStyle.stroke
    ..color = Colors.green;

  /// 绘制表情图片用
  static final Paint _paint = Paint();

  static void updateSelfSendPaint(double strokeWidth) {
    _selfSendPaint.strokeWidth = strokeWidth;
  }

  static String? fontFamily;

  // ---------------------------------------------------------------------------
  // 表情弹幕支持
  // ---------------------------------------------------------------------------

  /// 已缓存的表情图片
  static ui.Image? emoteImage(String url) => _emoteCache[url];

  /// 预加载表情图片。直播/弹幕都是先拿 URL 再画，必须提前解码，
  /// 否则栅格化时拿不到图只能退化画文字。
  static Future<void> preloadEmotes(
    Iterable<DanmakuEmote> emotes, {
    Map<String, String>? headers,
  }) async {
    final pending = <String>{};
    for (final emote in emotes) {
      if (emote.url.isEmpty || _emoteCache.containsKey(emote.url)) continue;
      pending.add(emote.url);
    }
    for (final url in pending) {
      if (_emoteCache.containsKey(url)) continue;
      final image = await _loadEmoteImage(url, headers);
      if (image == null) continue;
      if (_emoteCache.length >= maxEmoteCacheSize) {
        final oldest = _emoteCache.keys.first;
        _emoteCache.remove(oldest);
      }
      _emoteCache[url] = image;
    }
  }

  static Future<ui.Image?> _loadEmoteImage(
    String url,
    Map<String, String>? headers,
  ) async {
    final client = HttpClient();
    try {
      final request = await client.getUrl(Uri.parse(url));
      headers?.forEach((key, value) => request.headers.set(key, value));
      final response = await request.close();
      if (response.statusCode != 200) return null;
      final builder = BytesBuilder(copy: false);
      await for (final chunk in response) {
        builder.add(chunk);
      }
      final bytes = builder.takeBytes();
      if (bytes.isEmpty) return null;
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      codec.dispose();
      return frame.image;
    } catch (_) {
      return null;
    } finally {
      client.close();
    }
  }

  /// 表情在弹幕里的显示尺寸：按字号归一，避免官方大表情糊满屏幕
  static ui.Size emoteDisplaySize(DanmakuEmote emote, double fontSize) {
    final rawWidth = emote.width > 0 ? emote.width : fontSize * 1.4;
    final rawHeight = emote.height > 0 ? emote.height : fontSize * 1.4;
    final height = rawHeight
        .clamp(fontSize * 1.2, fontSize * 2.4)
        .toDouble();
    return ui.Size(rawWidth * (height / rawHeight), height);
  }

  /// 把弹幕文本切成「文字 / 表情」片段
  static List<({String text, DanmakuEmote? emote})> emoteSegments(
    DanmakuContentItem content,
  ) {
    final text = content.text;
    final emotes = content.emotes;
    if (emotes == null || emotes.isEmpty || text.isEmpty) {
      return [(text: text, emote: null)];
    }
    final keys = emotes.keys
        .where((key) => key.isNotEmpty && text.contains(key))
        .toList()
      ..sort((a, b) => b.length.compareTo(a.length));
    if (keys.isEmpty) return [(text: text, emote: null)];

    final segments = <({String text, DanmakuEmote? emote})>[];
    var index = 0;
    while (index < text.length) {
      var matchStart = -1;
      String? matchKey;
      for (final key in keys) {
        final position = text.indexOf(key, index);
        if (position != -1 && (matchStart == -1 || position < matchStart)) {
          matchStart = position;
          matchKey = key;
        }
      }
      if (matchKey == null) {
        segments.add((text: text.substring(index), emote: null));
        break;
      }
      if (matchStart > index) {
        segments.add((text: text.substring(index, matchStart), emote: null));
      }
      segments.add((text: matchKey, emote: emotes[matchKey]));
      index = matchStart + matchKey.length;
    }
    return segments;
  }

  static void _addContentSpans(
    ui.ParagraphBuilder builder,
    DanmakuContentItem content,
    ui.TextStyle style,
    double fontSize,
  ) {
    builder.pushStyle(style);
    for (final segment in emoteSegments(content)) {
      final emote = segment.emote;
      if (emote == null) {
        if (segment.text.isNotEmpty) builder.addText(segment.text);
      } else {
        final size = emoteDisplaySize(emote, fontSize);
        builder.addPlaceholder(
          size.width,
          size.height,
          ui.PlaceholderAlignment.middle,
        );
      }
    }
    builder.pop();
  }

  /// 把表情画进占位区域；图没加载好时退化画占位文字
  static void _drawEmotes(
    ui.Canvas canvas,
    ui.Paragraph paragraph,
    ui.Offset offset,
    DanmakuContentItem content,
  ) {
    final emotes = content.emotes;
    if (emotes == null || emotes.isEmpty) return;
    final segments = emoteSegments(content)
        .where((segment) => segment.emote != null)
        .toList();
    if (segments.isEmpty) return;
    final boxes = paragraph.getBoxesForPlaceholders();
    for (var i = 0; i < boxes.length && i < segments.length; i++) {
      final emote = segments[i].emote!;
      final box = boxes[i];
      final dst = ui.Rect.fromLTRB(
        offset.dx + box.left,
        offset.dy + box.top,
        offset.dx + box.right,
        offset.dy + box.bottom,
      );
      final image = _emoteCache[emote.url];
      if (image != null) {
        canvas.drawImageRect(
          image,
          ui.Rect.fromLTWH(
            0,
            0,
            image.width.toDouble(),
            image.height.toDouble(),
          ),
          dst,
          _paint,
        );
      } else {
        _drawEmoteFallback(canvas, dst, segments[i].text);
      }
    }
  }

  static void _drawEmoteFallback(ui.Canvas canvas, ui.Rect rect, String text) {
    if (text.isEmpty || rect.width <= 0 || rect.height <= 0) return;
    final builder = ui.ParagraphBuilder(ui.ParagraphStyle(
      textAlign: TextAlign.left,
      textDirection: TextDirection.ltr,
      fontFamily: fontFamily,
      maxLines: 1,
    ))
      ..pushStyle(ui.TextStyle(
        color: const ui.Color(0xFFFFFFFF),
        fontSize: rect.height * 0.55,
      ))
      ..addText(text);
    final paragraph = builder.build()
      ..layout(ui.ParagraphConstraints(width: rect.width));
    canvas.drawParagraph(paragraph, ui.Offset(rect.left, rect.top));
    paragraph.dispose();
  }

  static ui.Paragraph generateParagraph({
    required DanmakuContentItem content,
    required double fontSize,
    required int fontWeight,
  }) {
    final builder = ui.ParagraphBuilder(ui.ParagraphStyle(
      textAlign: TextAlign.left,
      fontWeight: FontWeight.values[fontWeight],
      textDirection: TextDirection.ltr,
      fontFamily: fontFamily,
      maxLines: 1,
    ));

    if (content.count case final count?) {
      builder
        ..pushStyle(ui.TextStyle(
          color: content.color,
          fontSize: fontSize * 0.6,
        ))
        ..addText('($count)')
        ..pop();
    }

    _addContentSpans(
      builder,
      content,
      ui.TextStyle(color: content.color, fontSize: fontSize),
      fontSize,
    );

    return builder.build()
      ..layout(const ui.ParagraphConstraints(width: double.infinity));
  }

  static ui.Image recordDanmakuImage({
    required ui.Paragraph contentParagraph,
    required DanmakuContentItem content,
    required double fontSize,
    required int fontWeight,
    required double strokeWidth,
  }) {
    double w = contentParagraph.maxIntrinsicWidth + strokeWidth;
    double h = contentParagraph.height + strokeWidth;

    final offset = Offset(
      (strokeWidth / 2.0) + (content.selfSend ? 2.0 : 0.0),
      strokeWidth / 2.0,
    );

    final rec = ui.PictureRecorder();
    final canvas = ui.Canvas(rec);
    if (devicePixelRatio != 1) {
      canvas.scale(devicePixelRatio);
    }

    if (strokeWidth != 0) {
      final builder = ui.ParagraphBuilder(ui.ParagraphStyle(
        textAlign: TextAlign.left,
        fontWeight: FontWeight.values[fontWeight],
        textDirection: TextDirection.ltr,
        fontFamily: fontFamily,
        maxLines: 1,
      ));
      final Paint strokePaint = Paint()
        ..shader = content.isColorful
            ? const LinearGradient(
                    colors: [Color(0xFFF2509E), Color(0xFF308BCD)])
                .createShader(Rect.fromLTWH(0, 0, w, h))
            : null
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth;

      if (!content.isColorful) {
        strokePaint.color = Colors.black;
      }

      if (content.count case final count?) {
        builder
          ..pushStyle(ui.TextStyle(
            fontSize: fontSize * 0.6,
            foreground: strokePaint,
          ))
          ..addText('($count)')
          ..pop();
      }

      _addContentSpans(
        builder,
        content,
        ui.TextStyle(fontSize: fontSize, foreground: strokePaint),
        fontSize,
      );

      final strokeParagraph = builder.build()
        ..layout(const ui.ParagraphConstraints(width: double.infinity));

      canvas.drawParagraph(strokeParagraph, offset);
      strokeParagraph.dispose();
    }

    canvas.drawParagraph(contentParagraph, offset);
    _drawEmotes(canvas, contentParagraph, offset, content);

    if (content.selfSend) {
      w += 4;
      canvas.drawRect(Rect.fromLTRB(0, 0, w, h), _selfSendPaint);
    }

    final pic = rec.endRecording();
    final img = pic.toImageSync(
      (w * devicePixelRatio).ceil(),
      (h * devicePixelRatio).ceil(),
    );
    pic.dispose();
    return img;
  }

  static ui.Image recordSpecialDanmakuImg({
    required SpecialDanmakuContentItem content,
    required int fontWeight,
    required double strokeWidth,
  }) {
    final builder = ui.ParagraphBuilder(ui.ParagraphStyle(
      textAlign: TextAlign.left,
      fontWeight: FontWeight.values[fontWeight],
      textDirection: TextDirection.ltr,
      fontSize: content.fontSize,
      fontFamily: fontFamily,
    ))
      ..pushStyle(ui.TextStyle(
        color: content.color,
        fontSize: content.fontSize,
        shadows: content.hasStroke
            ? [Shadow(color: Colors.black, blurRadius: strokeWidth)]
            : null,
      ))
      ..addText(content.text);

    final paragraph = builder.build()
      ..layout(const ui.ParagraphConstraints(width: double.infinity));

    final strokeOffset = strokeWidth / 2;
    final totalWidth = paragraph.maxIntrinsicWidth + strokeWidth;
    final totalHeight = paragraph.height + strokeWidth;

    final rec = ui.PictureRecorder();
    final canvas = ui.Canvas(rec);

    Rect rect;

    if (content.rotateZ != 0 || content.matrix != null) {
      rect = _calculateRotatedBounds(
        totalWidth,
        totalHeight,
        content.rotateZ,
        content.matrix,
      );

      if (devicePixelRatio != 1) {
        canvas.scale(devicePixelRatio);
      }
      canvas.translate(strokeOffset - rect.left, strokeOffset - rect.top);

      if (content.matrix case final matrix?) {
        canvas.transform(matrix.storage);
      } else {
        canvas.rotate(content.rotateZ);
      }
      canvas.drawParagraph(paragraph, Offset.zero);
    } else {
      rect = Rect.fromLTRB(0, 0, totalWidth, totalHeight);

      if (devicePixelRatio != 1) {
        canvas.scale(devicePixelRatio);
      }
      canvas.drawParagraph(paragraph, Offset(strokeOffset, strokeOffset));
    }
    paragraph.dispose();

    double width = rect.width * devicePixelRatio;
    double height = rect.height * devicePixelRatio;
    if (width > maxRasterizeSize || height > maxRasterizeSize) {
      final scaledMaxSize = maxRasterizeSize / devicePixelRatio;
      final left = rect.left;
      final top = rect.top;
      double right = rect.right;
      double bottom = rect.bottom;

      if (width > maxRasterizeSize) {
        right = left + scaledMaxSize;
        width = maxRasterizeSize;
      }

      if (height > maxRasterizeSize) {
        bottom = top + scaledMaxSize;
        height = maxRasterizeSize;
      }

      rect = Rect.fromLTRB(left, top, right, bottom);
    }

    content.rect = rect;

    final pic = rec.endRecording();
    final img = pic.toImageSync(width.ceil(), height.ceil());
    pic.dispose();

    return img;
  }

  static Rect _calculateRotatedBounds(
    double w,
    double h,
    double rotateZ,
    Matrix4? matrix,
  ) {
    final double cosZ;
    final double cosY;
    final double sinZ;
    if (matrix == null) {
      cosZ = cos(rotateZ);
      sinZ = sin(rotateZ);
      cosY = 1;
    } else {
      cosZ = matrix[5];
      sinZ = matrix[1];
      cosY = matrix[10];
    }

    final wx = w * cosZ * cosY;
    final wy = w * sinZ;
    final hx = -h * sinZ * cosY;
    final hy = h * cosZ;

    final minX = _min4(0.0, wx, hx, wx + hx);
    final maxX = _max4(0.0, wx, hx, wx + hx);
    final minY = _min4(0.0, wy, hy, wy + hy);
    final maxY = _max4(0.0, wy, hy, wy + hy);

    return Rect.fromLTRB(minX, minY, maxX, maxY);
  }

  @pragma("vm:prefer-inline")
  static double _min4(double a, double b, double c, double d) {
    final ab = a < b ? a : b;
    final cd = c < d ? c : d;
    return ab < cd ? ab : cd;
  }

  @pragma("vm:prefer-inline")
  static double _max4(double a, double b, double c, double d) {
    final ab = a > b ? a : b;
    final cd = c > d ? c : d;
    return ab > cd ? ab : cd;
  }
}
